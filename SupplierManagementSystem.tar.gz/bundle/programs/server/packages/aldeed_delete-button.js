(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['aldeed:delete-button'] = {};

})();

//# sourceMappingURL=aldeed_delete-button.js.map

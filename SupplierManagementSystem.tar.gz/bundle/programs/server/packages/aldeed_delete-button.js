(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/aldeed_delete-button/packages/aldeed_delete-button.js    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['aldeed:delete-button'] = {};

})();

//# sourceMappingURL=aldeed_delete-button.js.map
